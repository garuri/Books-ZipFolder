﻿using BooksApp.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;


namespace BooksApp
{
    class Program
    {

        private const int GSTPercentage = 10;
        private const decimal deliveryFee = 5.95m;
        private const decimal discountLimit = 20m;

        static void Main(string[] args)
        {
            try
            {
                List<Books> books;
                List<Discounts> currentDiscounts;
                List<Purchases> purchases;

                PopulateData(out books, out currentDiscounts, out purchases);

                CalculatePurchasePrice(books, currentDiscounts, purchases);

            }
            catch (Exception ex)
            {
              Console.WriteLine($"\n\t Error processing order :  {ex.StackTrace}.");

            }
        }

        private static void CalculatePurchasePrice(List<Books> books, List<Discounts> currentDiscounts, List<Purchases> purchases)
        {
            var totalPriceWithoutTax = 0m;
            var totalPriceWithTax = 0m;

            var finalBookPrice = 0m;
            var totalBookPrice = 0m;

            //Find price for the purchase
            //Check category for discounts
            //Check if delivery fee applies
            //Add GST


            foreach (var purchase in purchases)
            {
                var bookDetails = books.Find(b => b.Title == purchase.Title);
                var discount = currentDiscounts.Find(b => b.Genre == bookDetails.Genre);

                var unitprice = decimal.Parse(bookDetails.UnitPrice);

                if (discount != null)
                {
                    finalBookPrice = unitprice - (unitprice * discount.DiscountPercent / 100) * purchase.Quantity;
                }
                else
                {
                    finalBookPrice = (unitprice * purchase.Quantity);
                }

                totalBookPrice = totalBookPrice + finalBookPrice;
            }

            if (totalBookPrice < discountLimit)
                totalPriceWithoutTax = totalBookPrice + deliveryFee;
            else
                totalPriceWithoutTax = totalBookPrice;

            Console.WriteLine($"\n\t Total Books Price without Tax:  {totalPriceWithoutTax}.");

            totalPriceWithTax = (totalPriceWithoutTax + (totalPriceWithoutTax * GSTPercentage / 100));

            Console.WriteLine($"\n\t Total Books Price with Tax:  {totalPriceWithTax}.");
        }

        private static void PopulateData(out List<Books> books, out List<Discounts> currentDiscounts, out List<Purchases> purchases)
        {
            //Read & store Available Booklist

            var _filepath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);

            var booksData = File.ReadAllText(_filepath + @"//InputFiles//Books.json");


            books = new List<Books>();
            books = JsonConvert.DeserializeObject<List<Books>>(booksData);


            currentDiscounts = new List<Discounts>();
            var discountsData = File.ReadAllText(_filepath + @"//InputFiles//Discounts.json");
            currentDiscounts = JsonConvert.DeserializeObject<List<Discounts>>(discountsData);


            purchases = new List<Purchases>();
            var purchaseData = File.ReadAllText(_filepath + @"//InputFiles//Purchases.json");
            purchases = JsonConvert.DeserializeObject<List<Purchases>>(purchaseData);
        }
    }
}
